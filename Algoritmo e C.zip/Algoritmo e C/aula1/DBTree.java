

public class DBTree
{
	private DTNode raiz;
	
	public DBTree(Object r)
	{
		raiz = new DTNode(r);	
	}
	
	public DTNode getRaiz()
	{
		return raiz;
	}
	
	public void showItems(DTNode r)
	{
		if (r != null)
		{
			System.out.print(r.getData() + " ");
			showItems(r.getLeft());
			showItems(r.getRight());
		}
		return;
	}
	
	public void appendLeft(DTNode r, DTNode node)
	{
		if (r.getLeft() == null)
			r.setLeft( node );
		else if (r.getRight() == null)
			r.setRight( node );
		else
			appendLeft(r.getLeft(), node);		
		
		node.setFather(r);
	}
	
	public void appendRight(DTNode r, DTNode node)
	{
		if (r.getRight() == null)
			r.setRight( node );
		else if (r.getLeft() == null)
			r.setLeft( node );
		else
			appendRight(r.getRight(), node);	

		node.setFather(r);
	}
	
	public static void showAncestrais(DTNode node)
	{
		if(node.getFather() == null)
			return;
		
		System.out.print(node.getFather().getData()+" ");
		
		showAncestrais(node.getFather());
	}
	
	public static void main(String args[])
	{
		DBTree t = new DBTree("A");	
		
		t.appendLeft(t.getRaiz(), new DTNode("B"));
		t.appendLeft(t.getRaiz(), new DTNode("C"));
		
		t.appendLeft(t.getRaiz().getLeft(), new DTNode("D"));
		t.appendLeft(t.getRaiz().getLeft(), new DTNode("E"));
		
		t.appendLeft(t.getRaiz().getRight(), new DTNode("F"));
		t.appendLeft(t.getRaiz().getRight(), new DTNode("G"));
		
		t.showItems(t.getRaiz());
		
		System.out.println();
		
		showAncestrais(t.getRaiz().getLeft().getLeft());
	}
}