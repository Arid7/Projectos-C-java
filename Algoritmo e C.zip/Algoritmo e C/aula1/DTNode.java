

public class DTNode
{
	private Object data;
	private DTNode left, right, father;
	
	public DTNode(Object info)
	{
		data = info;
		left = right = father = null;
	}
	
	//---- metodos gets
	public Object getData()
	{
		return data;
	}
	public DTNode getLeft()
	{
		return left;
	}
	public DTNode getRight()
	{
		return right;
	}
	public DTNode getFather()
	{
		return father;
	}
	
	//---- metodos sets
	public void setData(Object newData)
	{
		data = newData;
	}
	public void setLeft(DTNode newLeft)
	{
		left = newLeft;
	}
	public void setRight(DTNode newRight)
	{
		right = newRight;
	}
	public void setFather(DTNode newFather)
	{
		father = newFather;
	}
}