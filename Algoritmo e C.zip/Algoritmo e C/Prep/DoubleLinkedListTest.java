class DoubleLinkedListTest
{	
	public static void show(DoubleListNode node)
	{
		if(node == null)
			return;
		
		System.out.print(node.getInfo()+" ");
		show(node.getNext());
	}
	
	public static void append(DoubleListNode node, Object info) 
	{
		if(node.getNext() == null)
			node.setNext(new DoubleListNode(node,info,null));
		else
			append(node.getNext(),info);
	}
	
	public static void remove(DoubleListNode node, Object info)       
  	{
		if(node.getNext() == null)
			System.out.println("nao encontrado");
		
		else if(node.getNext().getInfo().equals(info))
		{
			node.setNext(node.getNext().getNext());
			if(node.getNext()!=null)
				node.getNext().setPrev(node);
		}
		else
			remove(node.getNext(),info);
	}
	
	public static void removeWithPosition(DoubleListNode node,int i, int pos)
  	{
		if(node.getNext() == null)
			System.out.println("nao encontrado");
		
		else if( i == pos)
		{
			node.setNext(node.getNext().getNext());
			if(node.getNext()!=null)
				node.getNext().setPrev(node);
		}
		else
			removeWithPosition(node.getNext(),i+1,pos);
	}
	
	public static void auxShowPrev(DoubleListNode node)
	{
		if(node.getNext() == null)
			showPrev(node);
		else
			auxShowPrev(node.getNext());
	}
	
	public static void showPrev(DoubleListNode node)
	{
		if(node.getInfo().equals("head"))
			return;
		
		System.out.print(node.getInfo()+" ");
		showPrev(node.getPrev());
	}
	
	public static void uniaoOrdenada(DoubleListNode node, DoubleListNode node2, DoubleListNode node3)
	{
		if(node == null && node2 == null)
			return;
		
		if( node2 == null || node !=null && ((String)node.getInfo()).charAt(0)<((String)node2.getInfo()).charAt(0))
		{
			node3.setNext(node);
			node = node.getNext();
		}
		else
		{
			node3.setNext(node2);
			node2 = node2.getNext();
		}	
		
		uniaoOrdenada(node,node2,node3.getNext());
	}
	
	//Ordene uma lista ligada usando o algoritmo de ordenação por inserção.
	public static void insertionSort(DoubleListNode node, DoubleListNode aux)
	{
		if(node == null)
			return;
		
		if(aux.getPrev().getInfo().equals("head") || ((String)aux.getPrev().getInfo()).charAt(0)<((String)aux.getInfo()).charAt(0) )
			insertionSort(node.getNext(),node.getNext());
		else
		{
			Object x = aux.getInfo();
			aux.setInfo(aux.getPrev().getInfo());
			aux.getPrev().setInfo(x);
			
			insertionSort(node,aux.getPrev());
		}
	}

	public static void main(String [] args)
	{
		DoubleLinkedList lista = new DoubleLinkedList();
		DoubleLinkedList lista2 = new DoubleLinkedList();
		DoubleLinkedList lista3 = new DoubleLinkedList();

		/*lista.prepend("L");
		lista.prepend("C");*/   //C,L
		
		append(lista.getHead(),"9");
		append(lista.getHead(),"0");
		append(lista.getHead(),"1");
		
		insertionSort(lista.getHead().getNext().getNext(),lista.getHead().getNext().getNext());
		show(lista.getHead().getNext());

		/*append(lista2.getHead(),"1");
		append(lista2.getHead(),"2");
		append(lista2.getHead(),"3");*/
		
		//uniaoOrdenada(lista.getHead().getNext(),lista2.getHead().getNext(),lista3.getHead());
		
		//remove(lista.getHead(),"O");
		//removeWithPosition(lista.getHead(),1,4);
		
		show(lista3.getHead().getNext());
		//auxShowPrev(lista.getHead());
	}
}