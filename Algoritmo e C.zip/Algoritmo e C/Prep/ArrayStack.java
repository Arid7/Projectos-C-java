
class ArrayStack
{
	private int fundo;
	private Object pilha[];
	
	public ArrayStack(int size)
	{
		pilha = new Object[size];
		fundo = -1;
	}
	
	public int getFundo()
	{
		return fundo;
	}
	
	public Object getElem(int pos)
	{
		return pilha[pos];
	}
	
	public boolean isEmpty()
	{
		return fundo == -1;
	}
	
	public boolean isFull()
	{
		return fundo+1 == pilha.length;
	}
	
	public void push(Object x)
	{
		pilha[++fundo] = x;
	}
	
	public Object pop()
	{
		return pilha[fundo--];
	}
}