
class DoubleCircLinkedList
{
	private DoubleListNode head;
	
	public DoubleCircLinkedList()
	{
		head = new DoubleListNode(null,"head",null);
		head.setPrev(head);
		head.setNext(head);
	}
	
	public DoubleListNode getHead()
	{
		return head;
	}
	
	public static void show(DoubleListNode node)
	{
		if(node.getInfo().equals("head"))
			return;
		
		System.out.print(node.getInfo()+" ");
		
		show(node.getNext());
	}
	
	public void append(DoubleListNode node, Object info)
	{
		if(node.getNext().getInfo().equals("head"))
		{
			DoubleListNode aux = new DoubleListNode(node,info,head);
		
			node.setNext(aux);
			head.setPrev(aux);
		}
		else
			append(node.getNext(),info);
	}
	
	public static void inverter(DoubleListNode inicio,DoubleListNode fim)
	{
		if( inicio.getInfo().equals(fim.getInfo()) || inicio.getPrev().getInfo().equals(fim.getInfo()) )
			return;
		
		Object x = inicio.getInfo();
		inicio.setInfo(fim.getInfo());
		fim.setInfo(x);
		
		inverter(inicio.getNext(),fim.getPrev());
	}
	
	public static void main(String []args)
	{
		DoubleCircLinkedList lista = new DoubleCircLinkedList();
		
		lista.append(lista.getHead(),"1");
		lista.append(lista.getHead(),"2");
		lista.append(lista.getHead(),"3");
		lista.append(lista.getHead(),"4");
		lista.append(lista.getHead(),"5");
		lista.show(lista.getHead().getNext());
		System.out.println();
		
		inverter(lista.getHead().getNext(),lista.getHead().getPrev());
		show(lista.getHead().getNext());
	}
}
