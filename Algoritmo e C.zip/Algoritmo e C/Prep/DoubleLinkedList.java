class DoubleLinkedList
{
	private DoubleListNode head;
	public DoubleLinkedList()
	{
		head = new DoubleListNode(null,"head",null);
	}
	public DoubleListNode getHead()
	{
		return head;
	}
	
	public void prepend(Object info)
	{
		DoubleListNode node = new DoubleListNode(head,info,head.getNext());    
		head.setNext(node);
		if(node.getNext()!=null)
			node.getNext().setPrev(node);
	}
}