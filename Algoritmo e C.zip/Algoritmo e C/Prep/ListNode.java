class ListNode
{
	private Object info;
	private ListNode next;
	
	public ListNode(Object info)
	{
		this.info = info;
		this.next = null;
	}
	
	public ListNode(Object info, ListNode next)
	{
		this.info = info;
		this.next = next;
	}
	
	public Object getInfo()
	{
		return info;
	}
	
	public ListNode getNext()
	{
		return next;
	}
	
	public void setInfo(Object info)
	{
		this.info = info;
	}
	
	public void setNext(ListNode next)
	{
		this.next = next;
	}
	
}