class DoubleListNode
{
	private Object info;
	private DoubleListNode prev,next;
	
	public DoubleListNode(DoubleListNode prev, Object info, DoubleListNode next)
	{
		this.prev = prev;
		this.info = info;
		this.next = next;
	}
	
	public Object getInfo()
	{
		return info;
	}
	public DoubleListNode getPrev()
	{
		return prev;
	}
	public DoubleListNode getNext()
	{
		return next;
	}
	
	public void setInfo(Object info)
	{
		this.info = info;
	}
	public void setPrev(DoubleListNode prev)
	{
		this.prev = prev;
		//prev.setNext(this);
	}
	public void setNext(DoubleListNode next)
	{
		this.next = next;
		//next.setPrev(this);
	}
}