public class LinkedListTest
{
	public static void show(ListNode node)
	{
		if(node == null)
			return;
		
		System.out.print(node.getInfo()+" ");
		
		show(node.getNext());
	}
	
	public static void showReverse(ListNode node)
	{
		if(node == null)
			return;
		
		showReverse(node.getNext());
		
		System.out.print(node.getInfo()+" ");
	}
	
	public static void append(ListNode lista, Object nodeInfo)
	{
		if(lista.getNext() == null)
			lista.setNext(new ListNode(nodeInfo));
		else
			append(lista.getNext(),nodeInfo);
	}
	
	public static void ordenar(ListNode lista, ListNode node)
	{
		if(lista == null || lista.getNext() == null)
			return;
		
		if(((String)lista.getInfo()).charAt(0)>((String)node.getInfo()).charAt(0))
		{
			Object aux = lista.getInfo();
			lista.setInfo(node.getInfo());
			node.setInfo(aux);
		}
		
		if(node.getNext() == null)
			ordenar(lista.getNext(),lista.getNext().getNext());
		else
			ordenar(lista,node.getNext());
	}
	
	public static void concaternacao(ListNode lista1, ListNode lista2, ListNode lista3)
	{
		if(lista1 == null && lista2 == null)
			return;
		
		if(lista1 == null)
		{
			concaternacao(lista2,lista1,lista3);
			return;
		}
		
		lista3.setNext(lista1);
		
		concaternacao(lista1.getNext(),lista2,lista3.getNext());
	}
	
	public static void uniao(ListNode lista1, ListNode lista2, ListNode lista3, ListNode headLista3)
	{
		if(lista1 == null && lista2 == null)
			return;
		
		if(lista1 == null)
		{
			uniao(lista2,lista1,lista3,headLista3);
			return;
		}
		
		if(!pertence(headLista3.getNext(),lista1))
		{
			lista3.setNext(new ListNode(lista1.getInfo()));
			lista3 = lista3.getNext();
		}
			
		uniao(lista1.getNext(),lista2,lista3,headLista3);
	}
	
	public static boolean pertence(ListNode lista, ListNode node)
	{
		if(lista == null)
			return false;
		return lista.getInfo().equals(node.getInfo()) || pertence(lista.getNext(),node);
	}
	
	public static void diferenca(ListNode lista1, ListNode lista2, ListNode lista3, ListNode headLista2)
	{
		if(lista1 == null)
			return;

		if(!pertence(headLista2,lista1))
		{
			lista3.setNext(new ListNode(lista1.getInfo()));
			lista3 = lista3.getNext();
		}
			
		diferenca(lista1.getNext(),lista2,lista3,headLista2);
	}
	
	public static void interseccao(ListNode lista1, ListNode lista2, ListNode lista3, ListNode headLista2)
	{
		if(lista1 == null)
			return;
		
		if(pertence(headLista2,lista1))
		{
			lista3.setNext(new ListNode(lista1.getInfo()));
			lista3 = lista3.getNext();
		}
			
		interseccao(lista1.getNext(),lista2,lista3,headLista2);
	}
	
	public static int tamanho(ListNode node)
	{
		if(node == null)
			return 0;
		return 1 + tamanho(node.getNext());
	}
	
	public static int tamanho2(ListNode node)
	{
		return node==null? 0 : 1 + tamanho2(node.getNext()); 
	}
	
	public static void removeNode(ListNode lista, Object x)
	{
		if(lista.getNext() == null)
			System.out.println("Nao encontrado");
			
		else if(lista.getNext().getInfo().equals(x))
			lista.setNext(lista.getNext().getNext());
		else
			removeNode(lista.getNext(),x);
	}
	
	public static int findPosicao(ListNode lista,ListNode node)
	{
		if(lista == null)
			return -1;
		
		if(lista.getInfo().equals(node.getInfo()))
			return 1;
		
		int pos = findPosicao(lista.getNext(),node);
		
		if(pos == -1)
			return -1;
		
		return 1 + pos;
	}
	
	public static int findPosicao2(ListNode lista,ListNode node, int pos)
	{
		if(lista == null)
			return -1;
		if(lista.getInfo().equals(node.getInfo()))
			return pos;
		return findPosicao2(lista.getNext(),node,pos+1);
	}
	
	public static int findPosicao3(ListNode lista,ListNode node)
	{
		if(lista == null)
			return -1;
		
		if(!lista.getInfo().equals(node.getInfo()))
			return 1 + findPosicao3(lista.getNext(),node);
		
		return 1;
	}
	
	public static void inverter(ListNode lista, ListNode aux, ListNode headLista, ListNode ultNode, ListNode headAux)
	{
		if(headLista.getNext().getInfo().equals(aux.getInfo()))
			headLista.setNext(headAux.getNext());
		
		else if(lista.getNext() == null || ( ultNode != null && lista.getNext().getInfo().equals(ultNode.getInfo())) )
		{
			aux.setNext(new ListNode(lista.getInfo()));
			inverter(headLista.getNext(),aux.getNext(),headLista,lista,headAux);
		}
		else
			inverter(lista.getNext(),aux,headLista,ultNode,headAux);
	}
	
	public static LinkedList inverterComPilha(ListNode node,ListNode aux, LinkedList listaAux, ArrayStack pilha)
	{
		if(node != null)
		{
			pilha.push(node.getInfo());
			return inverterComPilha(node.getNext(),aux,listaAux,pilha);
		}
		if(!pilha.isEmpty())
		{
			aux.setNext(new ListNode(pilha.pop()));
			return inverterComPilha(node,aux.getNext(),listaAux,pilha);
		}
		return listaAux;
	}
	
	public static ListNode inverterEf(ListNode node,ListNode aux, LinkedList lista) //1,2,3,4    4,3,2,1
	{
		if(node.getNext() == null)
			return node;
			
		ListNode aux2 = inverterEf(node.getNext(),aux,lista);

		append(aux,aux2.getInfo());
		
		if(lista.getHead().getNext().getInfo().equals(node.getInfo()))
			lista.getHead().setNext(aux.getNext());
		
		return node;
	}
	
	public static boolean ehCapicua(ListNode inicio, ListNode fim, ListNode lastNode)
	{
		if(inicio == null)
			return false;
		
		if(inicio.getNext() == null) 
			return true;
			
		if( lastNode != null && ( inicio.getInfo().equals(lastNode.getInfo()) || inicio.getNext().getInfo().equals(lastNode.getInfo())) )
			return true;
		
		if( fim.getNext() == null || (lastNode!=null && lastNode.getInfo().equals(fim.getNext().getInfo())) )
		{
			if(!inicio.getInfo().equals(fim.getInfo()))
				return false;
			return (ehCapicua(inicio.getNext(),inicio.getNext().getNext(),fim));
		}
		return ehCapicua(inicio,fim.getNext(),lastNode);
	}
			
	public static void main(String [] args)
	{
		LinkedList lista = new LinkedList();
		LinkedList lista2 = new LinkedList();
		ArrayStack pilha = new ArrayStack(3);
		
		append(lista.getHead(),"B");
		append(lista.getHead(),"E");
		append(lista.getHead(),"A");
		append(lista.getHead(),"F");
		
		//inverter(lista.getHead(),lista2.getHead(),lista.getHead(),null,lista2.getHead());
		//lista = inverterComPilha(lista.getHead().getNext(),lista2.getHead(),lista2,pilha);
		
		//inverterEf(lista.getHead(),lista2.getHead(),lista);
		
		//show(lista.getHead().getNext());
		
		//lista.prepend("Fogo");
		//removeNode(lista.getHead(),"A");
		
		//System.out.println(findPosicao(lista.getHead().getNext(),new ListNode("A")));
		
		//System.out.println(findPosicao2(lista.getHead().getNext(),new ListNode("D"),1));
		
		//System.out.println(findPosicao3(lista.getHead().getNext(),new ListNode("B")));
		
		//ordenar(lista.getHead().getNext(),lista.getHead().getNext().getNext());
		
		append(lista2.getHead(),"A");
		append(lista2.getHead(),"E");
	//	append(lista2.getHead(),"E");
		append(lista2.getHead(),"A");
		
		//LinkedList lista3 = new LinkedList();
		
		//concaternacao(lista.getHead().getNext(),lista2.getHead().getNext(),lista3.getHead());
		//uniao(lista.getHead().getNext(),lista2.getHead().getNext(),lista3.getHead(),lista3.getHead());
		//diferenca(lista.getHead().getNext(),lista2.getHead().getNext(),lista3.getHead(),lista2.getHead());
		//interseccao(lista.getHead().getNext(),lista2.getHead().getNext(),lista3.getHead(),lista2.getHead());
		
		//System.out.print(tamanho(lista2.getHead().getNext()));
		
		System.out.print(ehCapicua(lista2.getHead().getNext(),lista2.getHead().getNext().getNext(),null));
	
	}
}