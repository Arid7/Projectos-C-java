class DBTree
{
	private DTNode raiz;
	
	public DBTree(Object data)
	{
		raiz = new DTNode(data);
	}
	
	public DTNode getRaiz()
	{
		return raiz;
	}

	/*public static DTNode min(DTNode node)
	{
		if(node.getLeft() == null && node.getRight() == null)
			return node;
		
		if(node.getRight() == null )
			return min(node.getLeft());
	
		if(node.getLeft() == null )
			return min(node.getRight());
		
		DTNode minL = min(node.getLeft());
		DTNode minR = min(node.getRight());
		
		if( ((String)minL.getData()).compareTo((String)	minR.getData()) < 0 && ((String)minL.getData()).compareTo((String)node.getData()) < 0 )
			return minL;
		else if( ((String)minL.getData()).charAt(0) > ((String)minR.getData()).charAt(0) && ((String)minR.getData()).charAt(0) < ((String)node.getData()).charAt(0) ) 
			return minR;
		
		return node;  
	}*/
	
	public static DTNode min(DTNode node)
	{
		DTNode currentMin = node; 

		if(node.getLeft() != null )
		{
			DTNode left = min(node.getLeft());
			
			if( ((String)left.getData()).compareTo((String)currentMin.getData()) < 0 )
				currentMin = left;
		}
		
		if(node.getRight() != null )
		{
			DTNode right = min(node.getRight());
			
			if( ((String)right.getData()).compareTo((String)currentMin.getData()) < 0 )
				currentMin = right;
		}
		
		return currentMin;  
	}
	
	public static DTNode max(DTNode node)
	{
		if(node.getLeft() == null && node.getRight() == null)
			return node;
		
		if(node.getRight() == null )
			return max(node.getLeft());
	
		if(node.getLeft() == null )
			return max(node.getRight());
		
		DTNode maxL = max(node.getLeft());
		DTNode maxR = max(node.getRight());
		
		if( ((String)maxL.getData()).charAt(0) > ((String)maxR.getData()).charAt(0) && ((String)maxL.getData()).charAt(0) > ((String)node.getData()).charAt(0) )
			return maxL;
		else if( ((String)maxL.getData()).charAt(0) < ((String)maxR.getData()).charAt(0) && ((String)maxR.getData()).charAt(0) > ((String)node.getData()).charAt(0) ) 
			return maxR;
		
		return node;  
	}
	
	public static void minMax(DTNode node)
	{
		if(node == null)
			System.out.print("Arvore sem elem");
		else if(node.getLeft() == null && node.getRight() == null)
			System.out.print("min = max = "+node.getData());
		else
			System.out.print("Max = "+max(node).getData()+" e min = "+min(node).getData());
	}

	public static void appendLeft(DTNode raiz, DTNode node)
	{
		if(raiz.getLeft() == null)
			raiz.setLeft(node);
		else if(raiz.getRight() == null)
			raiz.setRight(node);
		else
			appendLeft(raiz.getLeft(),node);
		node.setFather(raiz);
	}
	
	public static void appendRight(DTNode raiz, DTNode node)
	{
		if(raiz.getRight() == null)
			raiz.setRight(node);
		else if(raiz.getLeft() == null)
			raiz.setLeft(node);
		else
			appendLeft(raiz.getRight(),node);
		node.setFather(raiz);
	}
	
	public static int descendentes(DTNode node)
	{
		if(node.getLeft() == null && node.getRight() == null)
			return 0;
		
		int total = (node.getLeft() != null ? 1:0) + (node.getRight() != null ? 1 : 0);

		return total + descendentes(node.getLeft()) + descendentes(node.getRight());
	}
	
	public static int TreeHeight(DTNode node)
	{
		if(node == null)
			return 0;
		
		return 1 + Math.max(TreeHeight(node.getLeft()),TreeHeight(node.getRight()));
	}
	
	public static int totalNos(DTNode node)
	{
		if(node == null)
			return 0;
		
		return 1 + totalNos(node.getLeft()) + totalNos(node.getRight());
	}
	
	public static boolean ehABB(DTNode node, Object min, Object max)
	{
		if(node == null)
			return true;
		
		if( (min!=null && ((String)node.getData()).compareTo((String)min)<=0) || (max!=null && ((String)node.getData()).compareTo((String)max)>=0))
			return false;
		
		return ehABB(node.getLeft(),min,node.getData()) && ehABB(node.getRight(),node.getData(),max);
	}
	
	public static void removeNodeABB(DTNode node, Object info)
	{
		if(node == null)
			System.out.println("Nao encontrado");
		
		else if( ((String)node.getData()).compareTo((String)info) == 0)
		{
			if(node.getFather() == null)
			{
				node.setData(null);
				node.setLeft(null);
				node.setRight(null);
			}
			else if( ((String)node.getFather().getLeft().getData()).compareTo((String)node.getData()) == 0 )
				node.getFather().setLeft(null);
			else
				node.getFather().setRight(null);
		}
		
		else if( ((String)node.getData()).compareTo((String)info) < 0 )
			removeNodeABB(node.getRight(),info);
		else
			removeNodeABB(node.getLeft(),info);
	}
	
	public static void show(DTNode node)
	{
		if(node == null)
			return;
		
		show(node.getLeft());
		System.out.print(node.getData()+" ");
		show(node.getRight());
	}
	
	public static void treeToList(DTNode node, ListNode nodeList)
	{
		if(node == null)
			return;
		
		treeToList(node.getLeft(),nodeList);
		
		ListNode aux = new ListNode(node.getData(),null);
		nodeList.setNext(aux);
		nodeList = aux;
		
		treeToList(node.getRight(),nodeList);
	}
	
	public static void showList(ListNode node)
	{
		if(node == null)
			return;
		
		System.out.print(node.getInfo()+" ");
		showList(node.getNext());
	}
	
	
	public static void inverterTree(DTNode node)
	{
		if(node.getLeft() == null && node.getRight() == null)
			return;
		
		/*if( node.getLeft()!=null && node.getRight()!=null)
		{
			Object aux = node.getLeft().getData();
			node.getLeft().setData(node.getRight().getData());
			node.getRight().setData(aux);
		}*/

		if( node.getLeft()!=null && node.getRight()!=null)
		{
			DTNode aux = node.getLeft();
			node.setLeft(node.getRight());
			node.setRight(aux);
		}
		
		inverterTree(node.getLeft());
		inverterTree(node.getRight());
	}
	
	public static DTNode maiorEmABB(DTNode node)
	{
		if(!isABB(node,null,null))
			return null;
		
		if(node.getRight() == null)
			return node;
		
		return maiorEmABB(node.getRight());
	}
	
	public static boolean isABB(DTNode node, Object left, Object right)
	{
		if(node == null)
			return true;
		
		if( left!=null && ((String)node.getData()).compareTo((String) left) <= 0 )
			return false;
		
		if( right!=null && ((String)node.getData()).compareTo((String) right) >= 0 )
			return false;
		
		return isABB(node.getLeft(),left,node.getData()) && isABB(node.getRight(),node.getData(),right);
	}

	public static void main(String []args)
	{
		DBTree arvore = new DBTree("6");
		
		LinkedList lista = new LinkedList();
		
		appendLeft(arvore.getRaiz(),new DTNode("4"));
		appendLeft(arvore.getRaiz().getLeft(),new DTNode("3"));
		appendLeft(arvore.getRaiz().getLeft(),new DTNode("5"));
		
		appendRight(arvore.getRaiz(),new DTNode("8"));
		appendRight(arvore.getRaiz().getRight(),new DTNode("9"));
		appendRight(arvore.getRaiz().getRight(),new DTNode("7"));
		
		//minMax(arvore.getRaiz());
		
		//System.out.print(descendentes(arvore.getRaiz()));
		
		//System.out.print(TreeHeight(arvore.getRaiz()));
		
		//System.out.print(totalNos(arvore.getRaiz()));
		
		//System.out.print(ehABB(arvore.getRaiz(),null,null));
		
		//removeNodeABB(arvore.getRaiz(),"2");
		
		//show(arvore.getRaiz());
		
		//treeToList(arvore.getRaiz(),lista.getHead());
		
		//showList(lista.getHead().getNext());
		
		//inverterTree(arvore.getRaiz());	

		//System.out.println();
		//show(arvore.getRaiz());
		
		System.out.println(maiorEmABB(arvore.getRaiz()).getData());
	}
}