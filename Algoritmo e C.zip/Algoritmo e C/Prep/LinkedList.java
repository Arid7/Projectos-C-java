
class LinkedList
{
	private ListNode head;
	
	public LinkedList()
	{
		head = new ListNode("head",null);
	}
	public ListNode getHead()
	{
		return head;
	}
	public void prepend(Object info)
	{
		head.setNext(new ListNode(info,head.getNext()));
	}
}