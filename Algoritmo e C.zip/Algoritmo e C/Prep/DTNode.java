public class DTNode 
{
	private Object data;
	private DTNode father, right, left;
  
	public DTNode(Object info) 
	{
		right = left = father = null;
		data = info;
	}
  
	public Object getData() 
	{
		return data;
	}
	public DTNode getFather() 
	{
		return father;
	}
	public DTNode getLeft() 
	{
		return left; 
	}
	public DTNode getRight() 
	{
		return right; 
	}
  
	public void setData(Object data) 
	{
		this.data=data;
	}
	public void setFather(DTNode father) 
	{
		this.father=father;
	}
	public void setLeft(DTNode left) 
	{
		this.left=left; 
	}
	public void setRight(DTNode right) 
	{
		this.right=right; 
	}
}