	public class DBTree
	{
		DTNode r;
		public DBTree(Object x)
		{
			r = new DTNode(x);	
		}

		public static void appendLeft(DTNode a, DTNode node)
		{
			if( a.getLeft() == null )
				a.setLeft(node);
			else if ( a.getRight() == null)
				a.setRight(node);
			else
				appendLeft(a.getLeft(),node);
		}
		
		public static void appendRight(DTNode a, DTNode node)
		{
			if ( a.getRight() == null)
				a.setRight(node);
			else if( a.getLeft() == null )
				a.setLeft(node);
			else
				appendRight(a.getRight(),node);
		}
		
		public static int nDescendentes(DTNode t) 
		{
			if(t == null)
				return 0;
			
			return (t.getLeft()!=null?1:0)+(t.getRight()!=null?1:0)+nDescendentes(t.getLeft())+nDescendentes(t.getRight());
		}
		
		/*
		public static int nDescendentes(DTNode t) 
		{
			if(t.getLeft() == null && t.getRight() == null)
				return 0;
			
			if(t.getLeft() != null && t.getRight() == null)
				return 1 + nDescendentes(t.getLeft());
			
			if(t.getLeft() == null && t.getRight() != null)
				return 1 + nDescendentes(t.getRight());
			
			return 2 + nDescendentes(t.getLeft()) + nDescendentes(t.getRight()); 
		}*/
		
		/*
		public static void showDescendentes(DTNode t) 
		{
			if(t.getLeft() != null)
			{
				System.out.print(t.getLeft().getData()+" ");
				showDescendentes(t.getLeft());
			}
				
			if(t.getRight() != null)
			{
				System.out.print(t.getRight().getData()+" "); 
				showDescendentes(t.getRight());
			}
		}
		*/
		
		public static int nAncestral(DTNode r,DTNode t) 
		{
			if (r == null)
				return -1;
			
			if (r.getData().equals(t.getData()))	
				return 0;
			
			int left = nAncestral(r.getLeft(),t);
			if (left != -1)
				return 1 + left;
			
			int right = nAncestral(r.getRight(),t);
			if (right != -1)
				return 1 + right;

			return -1;  
		}
		
		public static void showAnces(DTNode t) 
		{		
			if(t.getFather() != null)	
			{
				System.out.print(t.getFather().getData()+" "); 
				showAnces(t.getFather());
			}
		}

		/*
		public static int nAnces(DTNode t) 
		{		
			if(t.getFather() == null)
				return 0;
			return 1 + nAnces(t.getFather());
		}
		*/
		
		public static int nAnces(DTNode t) 
		{		
			return t.getFather() == null ? 0 : 1 + nAnces(t.getFather());
		}
		
		public static void show(DTNode t) //Pre ordem
		{
			if(t == null)
				return;
			
			System.out.print(t.getData()+" ");
			
			show(t.getLeft());
			show(t.getRight());
		}
		
		public static boolean xEhABB(DTNode t)
		{
			if(t.getLeft() == null && t.getRight() == null)
				return true;

			if( Integer.parseInt(String.valueOf(t.getLeft().getData())) > Integer.parseInt(String.valueOf(t.getData()))
				|| Integer.parseInt(String.valueOf(t.getRight().getData())) < Integer.parseInt(String.valueOf(t.getData())))
				return false;
				
			return xEhABB(t.getLeft()) && xEhABB(t.getRight());
		}
		
		public static boolean EhABB(DTNode t)
		{
			if(t.getLeft() == null && t.getRight() == null)
				return true;
			
			if(t.getRight()==null)
			{
				if( Integer.parseInt(String.valueOf(t.getLeft().getData())) > Integer.parseInt(String.valueOf(t.getData())) ) 
					return false;
				return EhABB(t.getLeft());
			}
			
			if(t.getLeft()==null)
			{
				if(Integer.parseInt(String.valueOf(t.getRight().getData())) > Integer.parseInt(String.valueOf(t.getData())))
					return false;
				return EhABB(t.getRight());
			}
			
			if( Integer.parseInt(String.valueOf(t.getLeft().getData())) > Integer.parseInt(String.valueOf(t.getData()))
				|| Integer.parseInt(String.valueOf(t.getRight().getData())) < Integer.parseInt(String.valueOf(t.getData())))
				return false;
				
			return EhABB(t.getLeft()) && EhABB(t.getRight());
		}
		
		/*public static boolean ExEhABB(DTNode t)
		{
			if(t == null)
				return true;
		
			return t.getLeft()== null ? true : false      xEhABB(t.getLeft()) && xEhABB(t.getRight());
		}*/
		
		public static boolean pertence(DTNode A, DTNode find)
		{
			if(A == null)
				return false;
			return find.getData().equals(A.getData()) || pertence(A.getLeft(),find) || pertence(A.getRight(),find);
		}
		
		/*
		public static void inter(DBTree arvA,DTNode a, DBTree arvB, DTNode b, DBTree c)
		{
			if(a == null)
				return;
			
			if(b == null)
			{
				inter(arvA,a.getLeft(),arvB,arvB.r,c);
				inter(arvA,a.getRight(),arvB,arvB.r,c);
				return;
			}
			 
			if(a.getData().equals(b.getData()) && !pertence(c.r,a))
			{
				c.appendLeft(c.r,a);
				inter(arvA,a.getLeft(),arvB,arvB.r,c);
				inter(arvA,a.getRight(),arvB,arvB.r,c);
				return;
			}
			
			inter(arvA,a,arvB,b.getLeft(),c);
			inter(arvA,a,arvB,b.getRight(),c);
		}
		*/
						
		public static void inter(DTNode a, DTNode arvB, DTNode arvC)
		{
			if(a == null)
				return;
			 
			if(pertence(arvB,a) && !pertence(arvC,a))
				appendLeft(arvC,new DTNode(a.getData()));
				
			inter(a.getLeft(),arvB,arvC);
			inter(a.getRight(),arvB,arvC);
		}
		
		public static void main (String []args)
		{
			/*
			DBTree arv = new DBTree("Info");
		
			DTNode node1 = new DTNode("Uno");
			arv.appendLeft(arv.r,node1);
			
			DTNode node2 = new DTNode("Duo");
			arv.appendRight(arv.r,node2);

			DTNode node3 = new DTNode("Uno1");
			arv.appendLeft(node1,node3);
			
			DTNode node4 = new DTNode("Uno2");
			arv.appendLeft(node1,node4);
			
			DTNode node5 = new DTNode("Duo1");
			arv.appendLeft(node2,node5);
			
			DTNode node6 = new DTNode("Duo2");
			arv.appendRight(node2,node6);*/

			//System.out.println("Numero de descendentes:" + nDescendentes(arv.r));
			
			//System.out.println("Numero de ancestrais:" + nAnces(node3));
			
			//System.out.println("Numero de ancestrais" + nAncestral(arv.r,node2));
			
			//showDescendentes(node1);
			
			DBTree arv = new DBTree("4");	
			
			arv.appendLeft(arv.r,new DTNode("2"));
			arv.appendRight(arv.r,new DTNode("6"));

			arv.appendLeft(arv.r,new DTNode("1"));
			arv.appendLeft(arv.r,new DTNode("3"));
			
			arv.appendRight(arv.r,new DTNode("7"));
			arv.appendRight(arv.r,new DTNode("5"));
			
			DBTree arv2 = new DBTree("4");
			
			arv2.appendLeft(arv2.r,new DTNode("2"));
			arv2.appendRight(arv2.r,new DTNode("6"));

			arv2.appendLeft(arv2.r,new DTNode("1"));
			arv2.appendLeft(arv2.r,new DTNode("3"));
			
			arv2.appendRight(arv2.r,new DTNode("7"));
			arv2.appendRight(arv2.r,new DTNode("5"));
			
			DBTree arv3 = new DBTree("");	

			//System.out.println("Eh arvore binaria:" + EhABB(arv.r));
			
			//System.out.println("Numero de ancestrais:" + nAnces(arv.r));
			
			//System.out.println("Numero de descendentes:" + nDescendentes(arv.r));
			
			inter(arv.r,arv2.r,arv3.r);
			
			show(arv3.r);
		}
	}