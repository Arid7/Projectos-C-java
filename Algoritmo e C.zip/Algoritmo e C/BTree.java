
class BTree
{
	private Object tree[];
	private int node;
	
	public BTree(Object info)
	{
		node = 1;
		tree = new Object[8]; 
		tree[node] = info;
	}
	
	public void append(Object info, int node)
	{
		if(tree[2*node] == null)
			tree[2*node] = info;
		else
			if(tree[2*node+1] == null)
				tree[2*node+1] = info;
	}
	
	public void show(int node)
	{
		if(tree[node] == null || node >= tree.length) 
			return;
		
		System.out.print(tree[node]+" ");
		
		show(2*node);
		show(2*node+1);
	}

	public static void main(String []args)
	{
		BTree arvore = new BTree("A");
		
		arvore.append("B",1);
		arvore.append("C",1);
		
		arvore.show(1);
	}	
}