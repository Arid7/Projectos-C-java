public class DTNode{
	private Object data;
	private DTNode left, right, father;
	public DTNode(Object info)
	{
		data = info;
		left = right = father = null;
	}
	public Object getData()
	{
		return data;
	}
	public DTNode getFather()
	{
		return father;
	}
	public DTNode getLeft()
	{
		return left;
	}
	public DTNode getRight()
	{
		return right;
	}
	public void setData(Object data)
	{
		this.data = data;
	}
	public void setFather(DTNode father)
	{
		this.father = father;
	}
	public void setLeft(DTNode left)
	{
		this.left = left;
		left.setFather(this);
	}
	public void setRight(DTNode right)
	{
		this.right = right;
		right.setFather(this);
	}
}