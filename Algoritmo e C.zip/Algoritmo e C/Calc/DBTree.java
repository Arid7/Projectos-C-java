public class DBTree
{
	private DTNode r;
	public DBTree(Object x)
	{
		r = new DTNode(x);	
	}
	
	public DTNode getRaiz()
	{
		return r;	
	}

	public static void appendLeft(DTNode a, DTNode node)
	{
		if( a.getLeft() == null )
			a.setLeft(node);
		else if ( a.getRight() == null)
			a.setRight(node);
		else
			appendLeft(a.getLeft(),node);
	}

	public static void appendRight(DTNode a, DTNode node)
	{
		if ( a.getRight() == null)
			a.setRight(node);
		else if( a.getLeft() == null )
			a.setLeft(node);
		else
			appendRight(a.getRight(),node);
	}
	
	public static void append(DTNode a, DTNode d,DTNode node)
	{
		if(d.getData().equals(""))
			d.setData(node.getData());
		else if(a.getFather() == null || a.getFather().getLeft().getData().equals(a.getData()))
			appendLeft(d,node);
		else
			appendRight(d,node);
	}

	public static void show(DTNode t) //Em ordem
	{
		if(t == null)
			return;
		
		System.out.print(t.getData()+" ");
		
		show(t.getLeft());
		show(t.getRight());
	}

	/*public static void calculadora(DTNode a, DTNode b, DTNode c, DTNode d)
	{
		if(a == null || b == null)
			return;
		
		char op = String.valueOf(b.getData()).charAt(0);
		
		DTNode node;

		switch (op)
		{
			case '+':
				node = new DTNode( Integer.parseInt((String) a.getData()) + Integer.parseInt((String) c.getData()) );
				append(a,d,node);				
				
			break;
			
			case '-':
				node = new DTNode( Integer.parseInt((String) a.getData()) - Integer.parseInt((String) c.getData()) );
				append(a,d,node);
			break;
			
			case '/':
				node = new DTNode( Float.parseFloat((String) a.getData()) / Integer.parseInt((String) c.getData()) );	
				append(a,d,node);
			break;
			
			case '*':
				node = new DTNode( Integer.parseInt((String) a.getData()) * Integer.parseInt((String) c.getData()) );			
				append(a,d,node);
			break;
//sub:res
			default:
				node = new DTNode( Integer.parseInt((String) a.getData()) % Integer.parseInt((String) c.getData()) );			
				append(a,d,node);
		}
		calculadora(a.getLeft(),b.getLeft(),c.getLeft(),d);
		calculadora(a.getRight(),b.getRight(),c.getRight(),d);
	}*/
	
	public static void calculadora(DTNode a, DTNode b, DTNode c, DTNode d)
	{
		if(a == null || c == null)
			return;
		
		//char op = String.valueOf( b.getData()).charAt(0);
		char op = ((String)b.getData()).charAt(0);

		switch (op)
		{
			case '+':
				d.setData(Integer.parseInt((String) a.getData()) + Integer.parseInt((String) c.getData()) );			
			break;
			
			case '-':
				d.setData( Integer.parseInt((String) a.getData()) - Integer.parseInt((String) c.getData()) );
			break;
			
			case '/':
				d.setData( Float.parseFloat((String) a.getData()) / Integer.parseInt((String) c.getData()) );	
			break;
			
			case '*':
				d.setData( Integer.parseInt((String) a.getData()) * Integer.parseInt((String) c.getData()) );			
			break;
//sub:res
			default:
				d.setData( Integer.parseInt((String) a.getData()) % Integer.parseInt((String) c.getData()) );			
		}
		
		if(a.getLeft()!=null)
			d.setLeft(new DTNode(""));
			
		if(a.getRight()!=null)
			d.setRight(new DTNode(""));	
		
		calculadora(a.getLeft(),b.getLeft(),c.getLeft(),d.getLeft());
		calculadora(a.getRight(),b.getRight(),c.getRight(),d.getRight());
	}

	public static void main (String []args)
	{
		DBTree arv = new DBTree("1");
	
		DTNode node1 = new DTNode("2");
		arv.appendLeft(arv.getRaiz(),node1);
		
		DTNode node2 = new DTNode("3");
		arv.appendRight(arv.getRaiz(),node2);

		DTNode node3 = new DTNode("4");
		arv.appendLeft(node1,node3);
		
		DTNode node4 = new DTNode("5");
		arv.appendLeft(node1,node4);
		
		DTNode node5 = new DTNode("6");
		arv.appendLeft(node2,node5);
		
		DTNode node6 = new DTNode("7");
		arv.appendRight(node2,node6);
		
		//__________________________________
		DBTree arv2 = new DBTree("-");

		DTNode node1a2 = new DTNode("+");
		arv2.appendLeft(arv2.getRaiz(),node1a2);
		
		DTNode node2a2 = new DTNode("-");
		arv2.appendRight(arv2.getRaiz(),node2a2);

		DTNode node3a2 = new DTNode("*");
		arv2.appendLeft(node1a2,node3a2);
		
		DTNode node4a2 = new DTNode("/");
		arv2.appendLeft(node1a2,node4a2);
		
		DTNode node5a2 = new DTNode("%");
		arv2.appendLeft(node2a2,node5a2);
		
		DTNode node6a2 = new DTNode("+");
		arv2.appendRight(node2a2,node6a2);
		
		DBTree arv3 = new DBTree("1");

		DTNode node1a3 = new DTNode("2");
		arv3.appendLeft(arv3.getRaiz(),node1a3);
		
		DTNode node2a3 = new DTNode("3");
		arv3.appendRight(arv3.getRaiz(),node2a3);

		DTNode node3a3 = new DTNode("4");
		arv3.appendLeft(node1a3,node3a3);
		
		DTNode node4a3 = new DTNode("5");
		arv3.appendLeft(node1a3,node4a3);
		
		DTNode node5a3 = new DTNode("6");
		arv3.appendLeft(node2a3,node5a3);
		
		DTNode node6a3 = new DTNode("7");
		arv3.appendRight(node2a3,node6a3);

		DBTree arv4 = new DBTree("");
		
		calculadora(arv.getRaiz(),arv2.getRaiz(),arv3.getRaiz(),arv4.getRaiz());
		
		show(arv.getRaiz());
		System.out.println();
		
		show(arv2.getRaiz());
		System.out.println();
		
		show(arv3.getRaiz());
		System.out.println();
		
		show(arv4.getRaiz());
	}
}